"use client"; // Required for useState and useEffect

import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";

interface Game {
  id: number;
  name: string;
  thumbnail: string;
}

export default function Home() {
  const [games, setGames] = useState<Game[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Define backend URL (replace with your actual exposed backend URL)
  const backendUrl = "https://5000-ils4h1rzqa3cbn3ynod54-38657343.manus.computer";

  useEffect(() => {
    const fetchGames = async () => {
      try {
        setLoading(true);
        setError(null);
        const response = await fetch(`${backendUrl}/api/v1/games`);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data: Game[] = await response.json();
        setGames(data);
      } catch (e: any) {
        console.error("Failed to fetch games:", e);
        setError(`Failed to load games: ${e.message}`);
      } finally {
        setLoading(false);
      }
    };

    fetchGames();
  }, []); // Empty dependency array means this runs once on mount

  return (
    <div className="flex flex-col min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="bg-gray-800 p-4 shadow-md">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold text-purple-400">CryptoCasino Pro</h1>
          <div>
            <Button variant="secondary" className="mr-2">Log In</Button>
            <Button variant="default">Sign Up</Button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-grow container mx-auto p-4 flex">
        {/* Sidebar - Game Categories */}
        <aside className="w-1/5 bg-gray-800 p-4 rounded-lg mr-4">
          <h2 className="text-xl font-semibold mb-4">Categories</h2>
          <ul className="space-y-2">
            <li><Button variant="ghost" className="w-full justify-start">Slots</Button></li>
            <li><Button variant="ghost" className="w-full justify-start">Live Casino</Button></li>
            <li><Button variant="ghost" className="w-full justify-start">Table Games</Button></li>
            <li><Button variant="ghost" className="w-full justify-start">Originals</Button></li>
            <li><Button variant="ghost" className="w-full justify-start">Favorites</Button></li>
          </ul>
        </aside>

        {/* Game Lobby */}
        <section className="w-4/5 bg-gray-800 p-4 rounded-lg">
          <h2 className="text-xl font-semibold mb-4">Featured Games</h2>
          {loading && <p>Loading games...</p>}
          {error && <p className="text-red-500">{error}</p>}
          {!loading && !error && (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {games.map((game) => (
                <div key={game.id} className="bg-gray-700 rounded-lg p-4 text-center aspect-square flex flex-col justify-center items-center">
                  {/* In a real app, use game.thumbnail for an img src */}
                  <p className="text-gray-300">{game.name}</p>
                  <p className="text-sm text-gray-500">(Thumbnail: {game.thumbnail})</p>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 p-4 text-center text-gray-500 text-sm">
        © 2025 CryptoCasino Pro. Responsible Gaming. Must be 18+.
      </footer>
    </div>
  );
}

